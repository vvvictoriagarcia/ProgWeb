// La URL de la API de Flask, asumiendo que está corriendo en el puerto 4000
const API_URL = 'http://localhost:4000/superheroes';

// Función principal para obtener y renderizar los datos
function cargarYRenderizarSuperheroes() {
    // 1. Obtener el contenedor principal
    const container = document.getElementById('app-container');
    container.innerHTML = ''; // Limpiamos el contenido inicial (el "Cargando...")

    // 2. Llamar a la API de forma asíncrona usando fetch y promesas [cite: 1878]
    axios.get(API_URL) // Usando Axios por ser el estándar moderno visto en el material [cite: 1879]
    .then(response => {
        // La respuesta exitosa se maneja en el .then() [cite: 1758]
        const superheroes = response.data;
        
        // 3. Iterar y crear elementos para cada superhéroe
        superheroes.forEach(hero => {
            // Creación del contenedor para cada héroe [cite: 957]
            const heroDiv = document.createElement('div'); 
            heroDiv.classList.add('hero-card'); // Para aplicar estilos CSS

            // Crear el <h2> para el nombre del superhéroe [cite: 17, 960]
            const nameH2 = document.createElement('h2');
            // Usamos innerHTML para asignar el texto [cite: 882]
            nameH2.innerHTML = hero.superhero; 

            // Crear el <p> para la habilidad [cite: 17, 960]
            const skillP = document.createElement('p');
            skillP.innerHTML = hero.skills;

            // Crear la imagen (Punto 4.g)
            const heroImg = document.createElement('img');
            // Nota: Asumo que tengo imágenes en una carpeta 'img/' con nombres como 'batman.jpg'
            const imageName = hero.superhero.toLowerCase().replace(' ', '_') + '.jpg'; 
            heroImg.src = `img/${imageName}`;
            heroImg.alt = `Imagen de ${hero.superhero}`;
            heroImg.style.width = '150px'; 
            heroImg.style.height = 'auto';


            // 4. Adjuntar los elementos al contenedor del héroe [cite: 964]
            heroDiv.appendChild(nameH2);
            heroDiv.appendChild(skillP);
            heroDiv.appendChild(heroImg);

            // 5. Adjuntar el contenedor del héroe al contenedor principal
            container.appendChild(heroDiv);
        });
    })
    .catch(error => {
        // La operación fallida se maneja en el .catch() [cite: 1759]
        container.innerHTML = '<h2>Error al cargar los datos: API no disponible o fallida.</h2>';
        console.error('Error al obtener los superhéroes:', error);
    });
}

// Ejecutar la función cuando el DOM esté completamente cargado (simulado)
// Idealmente se usa window.onload o addEventListener('DOMContentLoaded'), pero
// para simplicidad y dado que el script se carga al final, lo llamo directamente.
cargarYRenderizarSuperheroes();