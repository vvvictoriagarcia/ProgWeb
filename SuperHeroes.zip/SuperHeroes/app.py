from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/superheroes')
def get_superheroes():
    heroes = [
        {"superhero": "Batman", "skills": "Conocimiento científico"},
        {"superhero": "Superman", "skills": "Fuerza sobrehumana y capacidad para volar"},
        {"superhero": "Aquaman", "skills": "Dominación psiónica de la vida marina"},
        {"superhero": "Wonderwoman", "skills": "Superhumana y dominio de armas"}
    ]
    return jsonify(heroes)

if __name__ == '__main__':
    app.run(debug=True)
